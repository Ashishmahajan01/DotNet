﻿namespace TaxPolicyLib;
public  delegate  double TaxOperation(double amount);
